using lab8;
namespace TestProject1

{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void TestAddFirst()
        {
            LinkedList list = new LinkedList();
            list.AddFirst("Joe Blow");
            Assert.That(list.GetValue(0), Is.EqualTo("Joe Blow"));

        }
        [Test]
        public void TestAddLast()
        {
            LinkedList list = new LinkedList();
            list.AddFirst("Dave Daverson");
            Assert.That(list.GetValue(0), Is.EqualTo("Dave Daverson"));
        }
        [Test]
        public void TestRemoveFirst()
        {
            LinkedList list = new LinkedList();
            list.AddFirst("Jane Doe");
            list.AddFirst("Bob Bobberson");
            list.RemoveFirst();
            Assert.That(list.GetValue(0), Is.EqualTo("Jane Doe"));

        }
        [Test]
        public void TestRemoveLast()
        {
            LinkedList list = new LinkedList();
            list.AddFirst("Jane Doe");
            list.AddFirst("Bob Bobberson");
            list.RemoveLast();
            Assert.That(list.GetValue(0), Is.EqualTo("Bob Bobberson"));
        }
        [Test]
        public void TestGetValue()
        {
            LinkedList list = new LinkedList();
            list.AddFirst("Sam Sammerson");
            list.AddFirst("Dave Daverson");
            Assert.That(list.GetValue(1), Is.EqualTo("Sam Sammerson"));
        }
        [Test]
        public void TestSize()
        {
            LinkedList list = new LinkedList();
            list.AddFirst("John Blow");
            list.AddFirst("John Schmoe");
            list.AddFirst("John Smith");
            list.AddFirst("Dave Daverson");
            Assert.That(list.Count, Is.EqualTo(4));
        }
    }
}