﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab8
{
    public class LinkedList
    {
        public class Node
        {
            public string Value { get; set; }
            public Node Next { get; set; }
            public Node(string value)
            {
                Value = value;
                Next = null;
            }
        }
        private Node head;
        public int Count { get; private set; }
        public void AddFirst(string value)
        {
            Node newNode = new Node(value);

            newNode.Next = head;
            head = newNode;
            Count++;

        }
        public void AddLast(string value)
        {
            Node newNode = new Node(value);
            if (head == null)
            {
                head = newNode;
                return;
            }
            Node currentNode = head;
            while (currentNode.Next != null)
            {
                currentNode = currentNode.Next;
            }
            currentNode.Next = newNode;
            Count++;

        }
        public void RemoveFirst()
        {
            if (head == null)
            {
                return;
            }
            head = head.Next;
            Count--;
        }
        public void RemoveLast()
        {
            if (head == null)
            {
                return;
            }
            if (head.Next == null)
            {
                head = null;
                return;
            }
            Node currentNode = head;
            while (currentNode.Next.Next != null)
            {
                currentNode = currentNode.Next;
            }
            currentNode.Next = null;
            Count--;
        }
        public string GetValue(int index)
        {
            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException("Index is out of range.");
            }
            Node current = head;
            for (int i = 0; i < index; i++)
            {
                current = current.Next;
            }
            return current.Value;
        }
    }

        internal class Program
        {
            static void Main(string[] args)
            {
            }

        }
    
}



